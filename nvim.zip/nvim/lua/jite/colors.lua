function ColorMyPencils(color)
    color = color or "cyberdream"
    vim.cmd.colorscheme(color)

    require('cyberdream').setup({
        varian = "muted",
        borderless_pickers = true,
        transparent = true,
        styles = {
            comments = "italic",
            keywords = "bold",
            types = "italic,bold",
            variables = "bold",
            functions = "italic",
        },
        highlights = {
            Comment = { fg = "#00C084", bg = "NONE", italic = true },
            LineNr = { fg =  "#00C084"},

            -- More examples can be found in `lua/cyberdream/extensions/*.lua`
        },
    })

    -- hello can you see me?
    --
end

ColorMyPencils()
