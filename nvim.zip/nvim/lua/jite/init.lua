require("jite.set")
require("jite.remap")
require("jite.colors")

require("nvim-lsp-installer").setup {}

ColorMyPencils()

vim.pack.add {
    {src = 'https://github.com/neovim/nvim-lspconfig' },
}

vim.lsp.config('clangd', {
    cmd = {'clangd'},
    filetypes = {'c', 'cpp', 'h'},
})

vim.lsp.enable({'clangd'})

vim.o.autocomplete = true

vim.api.nvim_create_autocmd('LspAttach', {
      group = vim.api.nvim_create_augroup('my.lsp', {}),
      callback = function(ev)
        local client = assert(vim.lsp.get_client_by_id(ev.data.client_id))
        if client:supports_method('textDocument/completion') then
          vim.lsp.completion.enable(true, client.id, ev.buf, {autotrigger = true})
        end
      end,
    })

vim.opt.completeopt = {'menuone', 'noinsert'}

vim.o.pumheight = 5
