vim.keymap.set("n", "<leader>pv", vim.cmd.Ex)

vim.keymap.set("v", "J", ":m '>+1<CR>gv=gv")
vim.keymap.set("v", "K", ":m '<-2<CR>gv=gv")

vim.keymap.set("n", "n", "nzzzv")
vim.keymap.set("n", "N", "Nzzzv")

vim.keymap.set("x", "<leader>p", "\"_dP")

vim.keymap.set("n", "<C-h>", "b")
vim.keymap.set("n", "<C-l>", "w")
vim.keymap.set("n", "<A-h>", "^")
vim.keymap.set("n", "<A-l>", "$")
vim.keymap.set("n", "<C-k>", "{")
vim.keymap.set("n", "<C-j>", "}")
vim.keymap.set("n", "<A-k>", "1G")
vim.keymap.set("n", "<A-j>", "G")

vim.keymap.set("v", "<C-h>", "b")
vim.keymap.set("v", "<C-l>", "w")
vim.keymap.set("v", "<A-h>", "^")
vim.keymap.set("v", "<A-l>", "$")
vim.keymap.set("v", "<C-k>", "<C-u>")
vim.keymap.set("v", "<C-j>", "<C-d>")

vim.keymap.set("i", "<C-k>", "<Up>")
vim.keymap.set("i", "<C-j>", "<Down>")
vim.keymap.set("i", "<C-h>", "<Left>")
vim.keymap.set("i", "<C-l>", "<Right>")

vim.keymap.set("n", "<C-y>", "^y$")
vim.keymap.set("n", "<leader>y", "y$")

vim.keymap.set("n", "<leader>s", ":%s/\\<<C-r><C-w>\\>/<C-r><C-w>/gI<Left><Left><Left>")
vim.keymap.set("n", "<leader>x", "<cmd>!chmod +x %<CR>", { silent = ture })
vim.keymap.set("n", "<leader>/", ":noh<kEnter>")

vim.keymap.set("n", "<Tab>", "<C-W>l")
vim.keymap.set("n", "<leader><Tab>", "<C-W>h")
