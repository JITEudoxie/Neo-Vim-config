---@brief
---
--- https://github.com/dart-lang/sdk/tree/master/pkg/analysis_server/tool/lsp_spec
---
--- Language server for dart.

---@type vim.lsp.Config
return {
  cmd = { 'dart', 'language-server', '--protocol=lsp' },
  filetypes = { 'dart' },
  root_markers = { 'pubspec.yaml' },
  init_options = {
    onlyAnalyzeProjectsWithOpenFiles = true,
    suggestFromUnimportedLibraries = true,
    closingLabels = true,
    outline = true,
    flutterOutline = true,
  },
  ---@type lspconfig.settings.dartls
  settings = {
    dart = {
      completeFunctionCalls = true,
      showTodos = true,
    },
  },
}
